package com.example.insurance_discounts.data

data class Category(
    val id: String,
    val categoryName: String
)
