package com.example.insurance_discounts.data

data class InsurancesResponse(
    val insurances: List<Insurance>
)
