package com.example.insurance_discounts.data

data class LoginRequest(
    val emailAddress: String,
    val password: String
)
