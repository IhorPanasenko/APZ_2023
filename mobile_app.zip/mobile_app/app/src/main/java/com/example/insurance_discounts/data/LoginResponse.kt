package com.example.insurance_discounts.data

data class LoginResponse(
    val token: String,
)
