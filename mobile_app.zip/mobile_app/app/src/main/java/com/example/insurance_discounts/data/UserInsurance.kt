package com.example.insurance_discounts.data

data class UserInsurance (
    val startDate: String,
    val endDate: String,
    val policy: Insurance
)